import React from 'react';
import DashboardHome from './DashboardHome';

const Dashboard = () => {
  return <DashboardHome />;
};

export default Dashboard;


