package cl.duocuc.tallermecanico.model;

public enum Rol {
    ADMIN,
    CLIENTE
}


