package cl.duocuc.tallermecanico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TallerMecanicoApplication {

    public static void main(String[] args) {
        SpringApplication.run(TallerMecanicoApplication.class, args);
    }
}


